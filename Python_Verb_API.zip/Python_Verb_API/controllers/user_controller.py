# Import necessary modules and packages
from models.user_model import User
from database.__init__ import conn
import app_config as config
import bcrypt
from datetime import datetime, timedelta
from bson.objectid import ObjectId
import jwt

# Function to generate a hashed password using bcrypt
def generate_hash_password(password):
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode("utf-8"), salt)
    return hashed_password

# Function to create a new user
def create_user(user_information):
    try:
        # Instantiate a new User object and populate its attributes
        new_user = User()
        new_user.name = user_information["name"]
        new_user.email = user_information["email"]
        new_user.password = generate_hash_password(user_information["password"])

        # Access the database collection for users
        db_collection = conn.database[config.CONST_USER_COLLECTION]

        # Check if the email is already associated with an existing user
        if db_collection.find_one({'email': new_user.email}):
            return 'Duplicated User'

        # Insert the new user into the database collection
        created_user = db_collection.insert_one(new_user.__dict__)

        return created_user
    except Exception as err:
        raise ValueError("Error on creating user.", err)

# Function to authenticate and log in a user
def login_user(user_information):
    try:
        # Extract email and password from the user information
        email = user_information["email"]
        password = user_information["password"].encode('utf-8')

        # Access the database collection for users
        db_collection = conn.database[config.CONST_USER_COLLECTION]

        # Retrieve the user with the provided email from the database
        current_user = db_collection.find_one({'email': email})

        # Check if the user exists and if the provided password matches the stored hashed password
        if not current_user:
            return "Invalid Email"
        if not bcrypt.checkpw(password, current_user["password"]):
            return "Invalid Password"
        
        # Prepare user data for JWT token generation
        logged_user = {}
        logged_user['id'] = str(current_user['_id'])
        logged_user['email'] = current_user['email']
        logged_user['name'] = current_user['name']

        # Generate expiration time for the JWT token
        expiration = datetime.utcnow() + timedelta(seconds = config.JWT_EXPIRATION)

        # Generate JWT token with user data and expiration time
        jwt_data = {'email': logged_user['email'], 'id': logged_user['id'], 'exp': expiration}
        jwt_to_return = jwt.encode(payload = jwt_data, key = config.TOKEN_SECRET)
        
        return {'token': jwt_to_return, 'expiration': config.JWT_EXPIRATION, 'logged_user': logged_user}
    
    except Exception as err:
        raise ValueError("Error on trying to login.", err)

# Function to fetch all users from the database
def fetch_all_users():
    try:
        # Access the database collection for users
        db_collection = conn.database[config.CONST_USER_COLLECTION]
        users = []

        # Iterate through each user in the database and populate user data
        for user in db_collection.find():
            current_user = {}
            current_user["id"] = str(user["_id"])
            current_user["email"] = user["email"]
            current_user["name"] = user["name"]
            users.append(current_user)
        
        return users
    
    except Exception as err:
        raise ValueError("Error on trying to fetch users.", err)

# Function to create a new verb
def create_verb(data):
    db_collection = conn.database[config.CONST_VERB_COLLECTION]

    try:
        # Check if the verb already exists in the database
        if db_collection.find_one({'verb': data.get('verb')}):
            return 'Duplicated Verb'

        # Insert the new verb into the database collection
        created_verb = db_collection.insert_one(data)

        return created_verb
    except Exception as err:
        raise ValueError("Error on creating user.", err)

# Function to fetch all verbs from the database
def fetch_verbs():
    db_collection = conn.database[config.CONST_VERB_COLLECTION]
    verbs = []
    try:
        # Iterate through each verb in the database and populate verb data
        for obj in db_collection.find():
            verb = {}
            verb["id"] = str(obj["_id"])
            verb["verb"] = obj["verb"]
            verb["owner"] = obj["owner"]
            verbs.append(verb)
            
        return verbs
    except Exception as err:
        raise ValueError("Error on trying to fetch verbs.", err)

# Function to fetch a single verb from the database based on its ID
def fetch_single_verbs(id):
    try:
        db_collection = conn.database[config.CONST_VERB_COLLECTION]

        # Find the verb with the provided ID in the database
        obj = db_collection.find_one({'_id': ObjectId(id)})
        return [{'id': str(obj["_id"]), 'verb':obj["verb"], 'owner':obj["owner"]}]
    except Exception as err:
        raise ValueError("Error on trying to fetch verbs.", err)

# Function to delete a single verb from the database based on its ID
def delete_single_verbs(id):
    db_collection = conn.database[config.CONST_VERB_COLLECTION]
    try:
        # Delete the verb with the provided ID from the database
        obj = db_collection.delete_one({'_id': ObjectId(id)})
        return {"verbs_affected": obj.deleted_count}
    except Exception as err:
        raise ValueError("Error on trying to fetch verbs.", err)
