class User:
    def __init__(self):
        self.name = ""
        self.email = ""
        self.password = ""