CONST_MONGO_URL = "mongodb+srv://Harsharan:Python123@cluster0.cxgm8x3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
CONST_DATABASE = "LS3"
CONST_USER_COLLECTION = "users"
CONST_VERB_COLLECTION = "verbs"

JWT_EXPIRATION = 86400 * 30
TOKEN_SECRET = "python"

TEACHER_TOKEN = ''

