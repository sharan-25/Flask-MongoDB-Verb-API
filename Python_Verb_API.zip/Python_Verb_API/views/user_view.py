from flask import Blueprint, jsonify, request
from models.user_model import User
from database.__init__ import conn
import json
from bson.objectid import ObjectId
from controllers.user_controller import create_user, login_user, fetch_all_users, create_verb, fetch_verbs, fetch_single_verbs, delete_single_verbs
from helpers.token_validation import validate_jwt
import requests

# Define a blueprint named "user" for organizing related routes
user = Blueprint("user", __name__)

# Route for creating a new user
@user.route("/users/", methods=["POST"])
def create():
    try:
        # Load request data into JSON format
        data = json.loads(request.data)

        # Check if required fields are present in the request data
        if 'email' not in data:
            return jsonify({'error': 'Email is needed in the request.'}), 400
        if 'password' not in data:
            return jsonify({'error': 'Password is needed in the request.'}), 400
        if 'name' not in data:
            return jsonify({'error': 'Name is needed in the request.'}), 400

        # Call the create_user function to create a new user
        created_user = create_user(data)

        # Handle duplicate user creation attempt
        if created_user == "Duplicated User":
            return jsonify({'error': 'There is already a user with this email.'}), 400

        # Return the ID of the created user
        return jsonify({'id': str(created_user.inserted_id)})
    except ValueError:
        return jsonify({'error': 'Error on creating user.'}), 500

# Route for user login
@user.route("/users/login", methods=["POST"])
def login():
    try:
        # Load request data into JSON format
        data = json.loads(request.data)

        # Check if required fields are present in the request data
        if 'email' not in data:
            return jsonify({'error': 'Email is needed in the request.'}), 400
        if 'password' not in data:
            return jsonify({'error': 'Password is needed in the request.'}), 400

        # Call the login_user function to authenticate the user
        login_attempt = login_user(data)

        # Handle invalid email or password
        if login_attempt == "Invalid Email":
            return jsonify({'error': 'Email not found.'}), 401
        if login_attempt == "Invalid Password":
            return jsonify({'error': 'Invalid Password.'}), 401

        # Return token, expiration, and user details upon successful login
        return jsonify({'token': login_attempt['token'], "expiration": login_attempt['expiration'], "logged_user":  login_attempt["logged_user"]})
    except ValueError:
        return jsonify({'error': 'Error login user.'}), 500

# Route for fetching all users
@user.route("/users/", methods=["GET"])
def fetch():
    try:
        # Validate JWT token
        token = validate_jwt()

        # Handle missing or invalid token
        if token == 400:
            return jsonify({'error': 'Token is missing in the request.'}), 400
        if token == 401:
            return jsonify({'error': 'Invalid authentication token.'}), 401

        # Fetch all users
        users = fetch_all_users()

        # Return fetched users along with the token used for the request
        return jsonify({'users': users, 'request_made_by': token})

    except ValueError:
        return jsonify({'error': 'Error fetching users.'}), 500

# Route for fetching verb details from an external API
@user.route("/verbs/", methods=["GET"])
def verb():
    try:
        # Validate JWT token
        token = validate_jwt()
        
        # Handle missing or invalid token
        if token == 400:
            return jsonify({'error': 'Token is missing in the request.'}), 400
        if token == 401:
            return jsonify({'error': 'Invalid authentication token.'}), 401

        # Load request data into JSON format
        data = json.loads(request.data)
        
        # Define external API URL and headers
        external_api_url = 'https://lasalle-frenchverb-api-afpnl.ondigitalocean.app/v1/api/verb'
        headers = {'token':'278ef2169b144e879aec4f48383dce28e654a009cacf46f8b6c03bbc9a4b9d11'}
        
        # Check if 'verb' is present in the request data
        if not data.get('verb'):
            return jsonify({'error': 'invalid payload'}), 401

        # Make a GET request to the external API with the provided verb
        response = requests.get(external_api_url, headers=headers, json={'verb':data.get('verb')})

        # Handle errors and return response
        if response.status_code == 400:
            return jsonify({"error": 'Token is missing in the request, please try again'}), 401
        if response.status_code == 401:
            return jsonify({"error": 'Invalid authentication token, please login again'}), 403
        if response.status_code == 200:
            return jsonify(response.json()) 
        return jsonify({"error": response.json()["errorMessage"]})

    except ValueError:
        return jsonify({'error': 'Error fetching users.'}), 500

# Route for fetching random verbs from an external API
@user.route("/verbs/random/", methods=["GET"])
def verb_random():
    try:
        # Validate JWT token
        token = validate_jwt()
        if token == 400:
            return jsonify({'error': 'Token is missing in the request.'}), 400
        if token == 401:
            return jsonify({'error': 'Invalid authentication token.'}), 401

        # Load request data into JSON format
        data = json.loads(request.data)

        # Define external API URL and headers
        external_api_url = 'https://lasalle-frenchverb-api-afpnl.ondigitalocean.app/v1/api/verb/random'
        headers = {'token':'278ef2169b144e879aec4f48383dce28e654a009cacf46f8b6c03bbc9a4b9d11'}
        
        # Check if 'quantity' is present in the request data
        if not data.get('quantity'):
             return jsonify({'error': 'invalid payload'}), 401

        # Make a GET request to the external API to fetch random verbs
        response = requests.get(external_api_url, headers=headers, json={'quantity':data.get('quantity')})

        # Handle errors and return response
        if response.status_code == 400:
            return jsonify({"error": 'Token is missing in the request, please try again'}), 401
        if response.status_code == 401:
            return jsonify({"error": 'Invalid authentication token, please login again'}), 403
        if response.status_code == 200:
            return jsonify(response.json()) 
        return jsonify({"error": response.json()["errorMessage"]})

    except ValueError:
        return jsonify({'error': 'Error fetching users.'}), 500

# Route for saving favorite verbs
@user.route("/verbs/favorites/", methods=["POST"])
def save_verbs():
    try:
        # Validate JWT token
        token = validate_jwt()

        # Handle missing or invalid token
        if token == 400:
            return jsonify({"error": 'Token is missing in the request, please try again'}), 401
        if token == 401:
            return jsonify({"error": 'Invalid authentication token, please login again'}), 403

        # Load request data into JSON format
        data = json.loads(request.data)
        verb_data = {}

        # Extract verb data from the request
        verb_data['verb'] = data['verb']
        verb_data.update({'owner':token.get('id')})

        # Create a new verb entry
        created_verb = create_verb(verb_data)
        
        # Handle duplicate verb creation attempt
        if created_verb ==  'Duplicated Verb':
            return jsonify({'error': 'There is already a verb with this name.'}), 400

        # Return the ID of the created verb
        return jsonify({'id': str(created_verb.inserted_id)})

    except ValueError:
        return jsonify({'error': 'Error fetching users.'}), 500

# Route for fetching favorite verbs
@user.route("/verbs/favorites/", methods=["GET"])
def get_verbs():
    try:
        # Validate JWT token
        token = validate_jwt()

        # Handle missing or invalid token
        if token == 400:
            return jsonify({"error": 'Token is missing in the request, please try again'}), 401
        if token == 401:
            return jsonify({"error": 'Invalid authentication token, please login again'}), 403

        # Fetch all favorite verbs
        verbs = fetch_verbs()

        # Return fetched favorite verbs
        return jsonify({'verbs': verbs})

    except ValueError:
        return jsonify({'error': 'Error fetching users.'}), 500

# Route for fetching a single favorite verb or deleting it
@user.route("/verbs/favorites/<favoriteUid>/", methods=["GET", 'DELETE'])
def get_single_verbs(favoriteUid):
    try:
        # Validate JWT token
        token = validate_jwt()
        if token == 400:
            return jsonify({"error": 'Token is missing in the request, please try again'}), 401
        if token == 401:
            return jsonify({"error": 'Invalid authentication token, please login again'}), 403

        # Fetch or delete the specified favorite verb based on the request method
        if request.method == 'GET':
            verbs = fetch_single_verbs(favoriteUid)
            return jsonify({'verbs': verbs})
        if request.method == 'DELETE':
            verbs = delete_single_verbs(favoriteUid)
            return jsonify({'verbs': verbs})

    except ValueError:
        return jsonify({'error': 'Error fetching users.'}), 500
